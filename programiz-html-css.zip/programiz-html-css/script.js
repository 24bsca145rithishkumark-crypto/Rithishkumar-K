document.addEventListener('DOMContentLoaded', function () {

  // set current year

  const yearEl = document.getElementById('year');

  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // view work scroll

  const viewWorkBtn = document.getElementById('viewWorkBtn');

  if (viewWorkBtn) {

    viewWorkBtn.addEventListener('click', () => {

      document.getElementById('projects').scrollIntoView({ behavior: 'smooth' });

    });

    viewWorkBtn.addEventListener('keypress', (e) => { if (e.key === 'Enter') viewWorkBtn.click(); });

  }

  // form and submit behavior

  const contactForm = document.getElementById('contactForm');

  const toast = document.getElementById('successToast');

  // ensure Enter in any input will submit (requestSubmit works well)

  const inputs = contactForm.querySelectorAll('input');

  inputs.forEach(inp => {

    inp.addEventListener('keydown', (e) => {

      if (e.key === 'Enter') {

        e.preventDefault();

        contactForm.requestSubmit();

      }

    });

  });

  contactForm.addEventListener('submit', function (e) {

    e.preventDefault();

    const name = (document.getElementById('name') || {}).value || '';

    const email = (document.getElementById('email') || {}).value || '';

    const phone = (document.getElementById('phone') || {}).value || '';

    if (!name || !email || !phone) {

      alert('Please fill name, email and phone.');

      return;

    }

    // show demo toast

    if (toast) {

      toast.hidden = false;

      setTimeout(() => toast.hidden = true, 2500);

    }

    // Keep fields prefilled as requested

    console.log('Contact submitted (demo):', { name, email, phone });

  });

});